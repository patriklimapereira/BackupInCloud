﻿$wlSavePath    = Join-Path -Path (Split-Path $profile) -ChildPath "wl.xml"
$wlApiUri      = "https://apis.live.net/v5.0"
$wlOneNoteURI  = "https://www.onenote.com/api/v1.0/pages"

# ********** BEFORE USE SET $ClientID and $Secret IN Function Use-WindowsLive *******************************************
# For how to obtain them see: http://msdn.microsoft.com/EN-US/library/office/dn575426(v=office.15).aspx#sectionSection1
# ***********************************************************************************************************************

# For background See: http://blogs.technet.com/b/heyscriptingguy/archive/2013/07/03/using-the-live-rest-api-with-powershell.aspx   and
#      http://blogs.technet.com/b/heyscriptingguy/archive/2013/07/02/use-powershell-to-work-with-skydrive-for-powerful-automation.aspx
#      http://msdn.microsoft.com/en-us/library/live/ff621314.aspx 
# &    http://msdn.microsoft.com/en-us/library/office/dn575420(v=office.15).aspx

#region Logon / session / token management
Add-Type -AssemblyName System.Windows.Forms
Function Use-WindowsLive {
<#
.Synopsis
   Sets up session with Windows live; returns true if we have a valid session, false if not
.DESCRIPTION
   Checks to see if we have an valid existing session with Live. 
   If no session existed in this PowerShell session but a previous one was saved, load it
   If we had a session, but it has expired or been re-loaded , and offline_access was enabled, session is refreshed
   Otherwise pop up a logon form and get a token
#>
    [CmdletBinding()]
    [OutputType([Boolean])]
    Param (
        # Scopes that will be required. If we have a token, and subset of its scopes is requested, no need to get a new one. 
        #See http://msdn.microsoft.com/en-us/library/live/hh243646.aspx  for more on scopes 
        [ValidateSet('wl.offline_access',   'wl.signin',             'wl.basic',            'wl.emails', 'wl.imap',
                     'wl.contacts_create',  'wl.skydrive_update',    'wl.skydrive',         'wl.contacts_skydrive', 
                     'wl.calendars',        'wl.events_create',      'wl.calendars_update', 'wl.contacts_calendars',
                     'wl.contacts_photos',  'wl.photos',             'wl.birthday',         'wl.contacts_birthday',
                     'wl.postal_addresses', 'wl.work_profile',       'wl.phone_numbers',    'Office.onenote_create'  )]
        [string[]]$Scope = @('wl.signin',   'wl.offline_access',     'wl.basic',            'Office.onenote_create',                     
                             'wl.emails',   'wl.calendars_update',   'wl.contacts_create',  'wl.skydrive_update'     )   
    )
    $ClientID      = "YOUR ID GOES HERE"
    $Secret        = "SECRET  GOES HERE"      
    $wlCallBackUri = "https://login.live.com/oauth20_desktop.srf"
    $wlAuthUri     = "https://login.live.com/oauth20_authorize.srf?client_id=$ClientID&scope={0}&response_type=code&redirect_uri=$wlCallBackUri"
    $wlTokenUri    = "https://login.live.com/oauth20_token.srf"
    $wlTokenBody   = "client_id=$ClientID&redirect_uri=$wlCallBackUri&client_secret=$Secret"
    $MimeType      = "application/x-www-form-urlencoded" 

    If ((-not $wlRefresh) -and (Test-Path $wlSavePath) ) {
        Write-Verbose "No Refresh token, loading data from $wlSavePath" 
        Import-Clixml -path $wlSavePath | Convert-wlResponse
    }
    #Check requested scope matches scope of token;
    $scopeOK = $true
    if ($scope -and $wlScope) {
        Write-Verbose "Scope = $scope" 
        $Scope | foreach {$scopeOk = $scopeOk -and (($wlScope -contains $_ ))} 
    } 
    if ($scopeOK -and $wlAccess -and ((get-date) -lt $wlExpiry) ) { #  Checking time to run force refresh of loaded data.    
        write-verbose "Already have a token with the right scope and time to run" 
        return $true
    }
    elseif ($scopeOK -and $wlRefresh) {# Scope is OK, and we have a refresh token, so refreshing
        Write-Progress -Activity "Authenticating with Live.com" -Status "Getting Token from Server"
        Invoke-RestMethod  -Method Post -Uri $wlTokenUri -ContentType $MimeType -Body ($wlTokenBody + "&refresh_token=$wlRefresh&grant_type=refresh_token") |
            Convert-wlResponse -save -setExpiry -action "Refreshed token for "         
        Write-Progress -Activity "Authenticating with Live.com" -Status "Getting Token from Server" -Completed
    }
    else { # Send user to logon page, get response $URI containing a code & swap the code for an access token (& refresh token if scopes are right
        #region  Logon form: we're interested in the URI at the end of the process
        $DocComp  = { #script block for the on document complete event: Make URI accessible; close the form if URI has a code or an error
                      $Global:uri = $web.Url.AbsoluteUri
                      if ($Global:Uri -match "error=[^&]*|code=[^&]*") {$form.Close() }  
        }
        $web      = New-Object -TypeName System.Windows.Forms.WebBrowser -Property @{Width=420;Height=600;Url=($wlAuthUri -f ($Scope -join "%20")) }
        $form     = New-Object -TypeName System.Windows.Forms.Form       -Property @{Width=440;Height=640}  
        $web.Add_DocumentCompleted($DocComp)
        $form.Controls.Add($web)
        $form.Add_Shown({$form.Activate()})
        $form.ShowDialog() | Out-Null
        #endregion 
        if ($Uri       -match "code=([^&]*)") {# If we got a code, request & process the token for it
            Write-Progress -Activity "Authenticating with Live.com" -Status "Getting Token from Server"
            Invoke-RestMethod -Method Post -Uri $wlTokenUri -ContentType $MimeType -Body ($wlTokenBody + "&code=" + $Matches[1] +  "&grant_type=authorization_code") |
              Convert-wlResponse -save -setExpiry -action "Logged on as " 
             Write-Progress -Activity "Authenticating with Live.com" -Status "Getting Token from Server" -Completed
        }
        elseif ( $uri -match "error=([^&]*)") {Write-Warning ("Logon returned an error of " + $Matches[1])}
     }
     if ($wlAccess -and ((get-date) -lt $wlExpiry) ) {return $true}
     Else                                            {return $false}
}

Function Convert-wlResponse {
<#
.Synopsis
   Sets Global variables from REST Response to a WL login
.INPUTS
   Response
#>
  [CmdletBinding()]
  Param (# The response either read from a file, or fetched from the web service
       [Parameter(Mandatory=$true,ValueFromPipeline=$true)] $Response,
       # A message to put out to verbose to say if what we did
       [String]$Action = "Processed Response for",
       # Dump the info to an XML file
       [switch]$Save,
       # If the info is fresh from the web, set the expiry time, otherwise don't
       [switch]$SetExpiry
  ) 
    if ($Save)      { 
        Write-verbose "Saving to $wlSavePath" 
        Export-Clixml -Path $wlSavePath  -InputObject $Response -Depth 5
    } 
    $Global:wlAccess   = $Response.access_token
    $Global:wlScope    = $Response.scope -split "\s+"   
    $Global:wlRefresh  = $Response.refresh_token
    if ($setExpiry) { #if we're reading from a file: life in seconds is meaningless, don't set expiry or get the username either
        $Global:wlExpiry = (Get-Date).AddSeconds([int]$Response.expires_in -10 )
        if ($Response.access_token) {
           Write-Progress -Activity "Authenticating with Live.com" -Status "Getting Token from Server" -PercentComplete 50
           $Global:wlUser = (Invoke-RestMethod -Method Get -Uri "$wlApiUri/me?access_token=$wlAccess").name 
           Write-Verbose ($action + $Global:wlUser) 
        }
    } 
}
#endregion
#region OneDRIVE
Function Get-OneDrive {
<#
.Synopsis
   Gets a list of files and folders from OneDrive
.DESCRIPTION
   Gets files and folders, from OneDrive; the type of item may be restricted, and the search may be limited by name.
   In addition the function maintains a global variable $OneDrive
   The contents of folders which have previously been examined are accessible as properties of the $oneNote variable
 .EXAMPLE
   Get-OneDrive -init
   [Re]Initializes the $OneDrive Global variable. $OneDrive will have Quota, Available, and user name properties for later use.
   It will also have Camera_Roll, My_Documents, My_Photos and Public properties which link to special folders. Each item in the root folder 
 .EXAMPLE
    Get-OneDrive -filter albums,folders
    Returns a list of containers in the root folder
 .EXAMPLE
    Get-OneDrive -Location $OneDrive.Camera_Roll
    Returns the contents of the "Camera Roll" special folder using the $onenote.camera_roll Property to locate it
 .EXAMPLE
    Get-OneDrive presentations  -include "v*"
    Returns a list of items with names starting with V in the "presentations" folder
 .EXAMPLE
    Get-OneDrive -MyDocuments
    $OneDrive.My_Documents.Children.Count
    After getting the contents of the MyDocuments folder, it is possible to see details of that folder via $oneDrive
#>
  [CmdletBinding(DefaultParameterSetName='URI')] 
  Param (  #The location to get files from on skydrive; either this or 
           #one of  -MyDocuments, -MyPhotos or -Public options must be specified 
           [parameter(ValueFromPipeline=$true,ParameterSetName='URI',Position=0)]
           $Location,
           #Filters items by type. 
           [ValidateSet("albums", "folders", "photos", "videos" ,"audio")]
           $filter , 
           #Selects items by name 
           $include = "*", 
           #Use the "My Documents" Folder
           [parameter(ParameterSetName='Docs')]
           [switch]$MyDocuments,
           #Use the "My Photos" Folder
           [parameter(ParameterSetName='Photos')]
           [Switch]$MyPhotos,
           #Use the "Public" Folder
           [parameter(ParameterSetName='Public')]
           [switch]$Public ,
           #Reinitializes the $OneDrive global variable
           [parameter(ParameterSetName='Reboot')]
           [Switch]$init
  )
  process {
         if (-not (Use-WindowsLive -Scope "wl.basic", "wl.skydrive_update")) { Write-Warning "No windows live connection" ; Return }
         else {
            if ($init) {$global:OneDrive = $null}
            Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com"
            If     ( $MyDocuments -and $OneDrive.My_Documents)   {$Location = $OneDrive.My_Documents}
            elseIf ( $MyPhotos    -and $OneDrive.My_Photos)      {$Location = $OneDrive.My_Photos}
            elseIf ( $Public      -and $OneDrive.Public)         {$Location = $OneDrive.Public}
            elseif ( $Location    -is [string] -and $Location -notmatch "$wlApiUri/folder" ) { 
                $f =  $OneDrive.Children | where {$_.type -in "folder","album" -and $_.name -like $Location} 
                       If ($f.upload_location )                  {$Location = $f} 
            }  
            if (-not $Location)  {
                if (-not $global:OneDrive) { #If $OneDrive hasn't been initialized, do that now. 
                     $global:OneDrive  =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive?access_token=$wlAccess"
                     Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 13
                     $Quota                =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive/quota?access_token=$wlAccess"
                     Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 25
                     $global:OneDrive.pstypenames.Add("OneDriveItem")
                     Add-member -InputObject $Global:OneDrive -Name "GetItems"  -MemberType ScriptMethod -Value {Get-OneDrive $this} 
                     Add-Member -InputObject $Global:OneDrive -Name "Quota"     -MemberType NoteProperty -Value  $Quota.quota
                     Add-Member -InputObject $Global:OneDrive -Name "Available" -MemberType NoteProperty -Value  $Quota.available
                     Add-Member -InputObject $Global:OneDrive -Name "UserName"  -MemberType NoteProperty -Value  $Global:wlUser   
                }   
                $Location = $OneDrive
            }
            If   ($Location.children)                {$Items = $Location.children}
            else { 
                if     ($Location.upload_location )  {$RestURI = $Location.upload_location }
                elseif ($Location -is [string] )     {$RestURI = $Location                 }
                if     ($RestURI -notmatch "$wlApiUri/folder" ) {Write-Warning "Need a valid location: $RestURI" ; return}
                Else {   #can also have SortBy= name/updated/size  sort_order=descending. ?limit=2&offset=3. 
                    $Items = (Invoke-RestMethod -Uri ($RestURI + "?access_token=$wlAccess" )).data | where {$_.name -like $include} | foreach {$_.pstypenames.Add("OneDriveItem"); $_} #| sort @{e={if(($_.type -eq "Album") -or ($_.type -eq "Folder")){"0"+$_.name} Else {"1"+"$_.name"  }}} 
                    if ($Location.upload_location) {
                        Add-Member -InputObject $Location -name Children -membertype Noteproperty -Value $items -Force
                        $Location.children | foreach {
                             Add-member    -InputObject $Location -name ($_.name -replace "\W","_") -membertype Noteproperty -Value $_ -Force 
                             if ($_.type -eq "Folder" -or $_.type -eq "Album") {
                                    Add-member -InputObject $_ -name "GetItems" -membertype ScriptMethod -Value {Get-OneDrive $this} 
                             }
                             else  {Add-member -InputObject $_ -name "Download" -membertype ScriptMethod -Value {Copy-OneDriveItem $this} }
                        }
                    }
                    if ($global:OneDrive.Children -and -not $global:OneDrive.My_Documents) {
                         Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 38
                         $wlDocs               =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive/my_documents?access_token=$wlAccess"
                         Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 50
                         $wlPhotos             =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive/my_photos?access_token=$wlAccess"
                         Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 63 
                         $wlPublic             =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive/public_documents?access_token=$wlAccess"
                         Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 75 
                         $wlRecentDocs         =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive/recent_docs?access_token=$wlAccess"
                         Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -PercentComplete 88 
                         $wlCameraRoll         =  Invoke-RestMethod -Uri "$wlApiUri/me/skydrive/camera_roll?access_token=$wlAccess"
                         Add-member -Force -InputObject $wlRecentDocs -name "GetItems"   -MemberType ScriptMethod -Value {Get-OneDrive $this} 
                         Add-member -Force -InputObject $wlCameraRoll -name "GetItems"   -MemberType ScriptMethod -Value {Get-OneDrive $this} 
                         Add-Member -Force -InputObject $OneDrive     -Name My_Documents -MemberType NoteProperty -Value ($OneDrive.children | where upload_location -EQ  $wlDocs.upload_location  )
                         Add-Member -Force -InputObject $OneDrive     -Name My_Photos    -MemberType NoteProperty -Value ($OneDrive.children | where upload_location -EQ  $wlPhotos.upload_location  )
                         Add-Member -Force -InputObject $OneDrive     -Name Public       -MemberType NoteProperty -Value ($OneDrive.children | where upload_location -EQ  $wlPublic.upload_location  )
                         Add-Member -Force -InputObject $OneDrive     -Name Recent       -MemberType NoteProperty -Value ($wlRecentDocs  )
                         Add-Member -Force -InputObject $OneDrive     -Name Camera_Roll  -MemberType NoteProperty -Value ($wlCameraRoll )
                    } 
                }                                       
             }
             Write-Progress -Activity "Get-OneDrive" -Status "Reading data from Live.com" -Completed
             if ($filter) {return ($Items | where {($_.name -like $include) -and ($_.type -in ($filter -replace "s$","")) } )}
             else         {return ($Items | where {($_.name -like $include) }) } 
         }
  }
}

Function Copy-ToOnedrive {
<#
.Synopsis
  Copies a local file to OneDrive
.DESCRIPTION
   Takes one or more files and copies them to OneDrive. 
   You can specify the My Documents, My Photos, or Public folders
   Or specify the name of a root folder
   If the no folder is given, (or if a wildcard is given and it matches multiple folders)
   the command will prompt for a folder
.EXAMPLE
   dir *.jpg | Copy-ToOnedrive -MyPhotos
   Copies jpg files from the current folder to the "My Photos" folder in OneDrive
 .EXAMPLE
   Copy-ToOnedrive conference.pptx -Destination presentations 
   Copies a file to the "Presentations" folder on one drive
 .EXAMPLE
   Get-OneDrive presentations
   Copy-ToOnedrive conference.pptx -Destination $OneDrive.Presentations.Video
   After the contents of a folder have been viewed with Get-OneDrive it is 
   possible to refer to them with $onenote.folder notation. Here it is used for 
   the video sub-folder inside the Presentations root-folder  
#>
  [CmdletBinding(DefaultParameterSetName='URI')] 
  param (  #The local file(s) to copy to skydrive
           [parameter(ValueFromPipeline=$true,Mandatory=$true,Position=0)]
           [Alias("FullName","FileName")]$Path,
           #The location to place files in on skydrive; either this or 
           #one of  -MyDocuments, -MyPhotos or -Public options must be specified 
           [parameter(ParameterSetName='URI',Position=1,Mandatory=$true)]
           $Destination ,
           #Use the "My Documents" Folder
           [parameter(ParameterSetName='Docs')]
           [switch]$MyDocuments,
           #Use the "My Photos" Folder
           [parameter(ParameterSetName='Photos')]
           [Switch]$MyPhotos,
           #Use the "Public" Folder
           [parameter(ParameterSetName='Public')]
           [switch]$Public 
  ) 
  Process {
        if ($path.count -gt 1) {
                $PSBoundParameters.Remove("Path")  
                $path | Copy-ToOnedrive @PSBoundParameters }
        elseif (-not (Test-path $Path))                                   {Write-Warning "Can't Find $path" }
        elseif (-not (Use-WindowsLive "wl.basic", "wl.skydrive_update" )) {Write-Warning "No Access to Windows Live"}           
        else {
            $fnPart = "/" + (Split-Path -Leaf $Path) + "?access_token=$wlAccess"
            If ( $MyDocuments) {$URI   = $OneDrive.My_Documents.upload_location       + $fnPart }
            If ( $MyPhotos)    {$URI   = $OneDrive.My_Photos.upload_location          + $fnPart }
            If ( $Public)      {$URI   = $OneDrive.Public.upload_location             + $fnPart }
            if ( $Destination.upload_location)   {$URI = $Destination.upload_location + $fnPart }
            if (($Destination -match $wlApiUri)) {$URI = $Destination                 + $fnPart }
            else { $f =  $OneDrive.Children | where {$_.type -in "folder","album" -and $_.name -like $Destination} 
                    If ($f.upload_location )      { $Uri = $f.upload_location          + $fnPart } 
            }
            if (-not $Uri) {Write-Warning "Couldn't get a valid destination"}    
            else {
                Write-Progress -Activity "Uploading to OneDrive" -Status "Sending $path" 
                $ul = Invoke-RestMethod -Uri $Uri -Method Put -InFile $Path
                $ul.pstypenames.Add("OneDriveLink") 
                Write-Progress -Activity "Uploading to OneDrive" -Status "Sending $path" -Completed
                return $ul
            }
        }        
    }
}

Function Copy-OneDriveItem {
<#
.Synopsis
  Copies a OneDrive file to the local computer
.DESCRIPTION
   Takes items with a name and OneDrive ID and copies them locally.
   If the item has a type of Album or Folder it any items in it will be copied recursively.
   The name is preserved.
 .EXAMPLE
   Copy-OneDriveItem $OneDrive.Presentations 
   Copies the contents of the Presentations folder to in the root of OneDrive
   The files and subfolders will be copied to a folder named in "Presentations" in the current directory
 .EXAMPLE 
   Get-OneDrive -MyPhotos -include ac*  | Copy-OneDriveItem 
   Finds files with names starting "ac" in the "My Photos" folder and copies them to current directo
#>
  [CmdletBinding()]  
  param (#Item to copy 
       [parameter(ValueFromPipeline=$true,Mandatory=$true)]
       $Item , 
       #Folder to put it in.
       $Destination = $PWD
  )
  process {
        If ($item -is [array])   { $item | Copy-OneDriveItem -Destination $Destination }
        If (-not (Use-WindowsLive  -Scope "wl.basic", "wl.skydrive_update")) {Write-Warning "No Access to Windows Live"}  
        elseif (-not ($item.name -and $item.id) )                            {Write-Warning "Not a valid item"}
        else {      
            $outFile = Join-Path $Destination $item.name 
            if ($item.type -in "Folder","Album" ) {
                Write-Verbose "Item is a $($item.type), copying recursively"
                [VOID](mkdir $Outfile)
                Get-OneDrive $item | Copy-OneDriveItem -Destination $outFile 
            }
            else {Invoke-RestMethod -Uri "$wlApiUri/$($item.id)/content?access_token=$wlAccess" -OutFile $outFile }
        }       
  }
}

Function Remove-OneDriveItem {
<#
.Synopsis
  Deletes a OneDrive file
.DESCRIPTION
  Takes items with a name and OneDrive ID and Deletes it.
.EXAMPLE
  Remove-OneDriveItem $OneDrive.Public.foo.zip
.EXAMPLE 
  Get-OneDrive -MyPhotos -include Img67*.jpg | Remove-OneDriveItem
  Finds files in the "My Photos" folder and deletes them
#>
  [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]  
  param (#Item to Delete 
         [parameter(ValueFromPipeline=$true,Mandatory=$true)]$Item  
  )
  process {
        If ($item -is [array])   { $item | Remove-OneDriveItem }
        If (-not (Use-WindowsLive  -Scope "wl.basic", "wl.skydrive_update")) {Write-Warning "No Access to Windows Live"}  
        elseif (-not ($item.name -and $item.id) )                            {Write-Warning "Not a valid item"}
        elseif ($PSCmdlet.ShouldProcess(($item.type + ": " + $item.name),"Delete OneDrive item")) { 
                Invoke-RestMethod -Method Delete -Uri "$wlApiUri/$($item.id)?access_token=$wlAccess" }       
  }
}

Function New-OneDriveFolder {
<#
.Synopsis
  Creates a OneDrive file
.DESCRIPTION
  Takes one or more names and an location with a name and OneDrive ID and a type of folder or album and creates the named folders in the location
.EXAMPLE 
  New-OneDriveFolder -Name "snaps","Better Pics" -MyDocuments
#>
  [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="Low",DefaultParameterSetName='URI')]  
  param (#Name for the new subfolder
         [parameter(ValueFromPipeline=$true,Mandatory=$true,Position=0)]$Name, 
         #Folder where subfolder should be created
         [parameter(ParameterSetName='URI',Mandatory=$true,Position=1)]$Location,
         #Use the "My Documents" Folder
         [parameter(ParameterSetName='Docs')]
         [switch]$MyDocuments,
         #Use the "My Photos" Folder
         [parameter(ParameterSetName='Photos')]
         [Switch]$MyPhotos,
         #Use the "Public" Folder
         [parameter(ParameterSetName='Public')]
         [switch]$Public 
  )
  process {
        If     ( $MyDocuments -and $OneDrive.My_Documents)   {$Location = $OneDrive.My_Documents}
        elseIf ( $MyPhotos    -and $OneDrive.My_Photos)      {$Location = $OneDrive.My_Photos}
        elseIf ( $Public      -and $OneDrive.Public)         {$Location = $OneDrive.Public}
        If ($name -is [array])   { $Name | New-OneDriveFolder -Location $Location }
        elseIf (-not (Use-WindowsLive  -Scope "wl.basic", "wl.skydrive_update")) {Write-Warning "No Access to Windows Live"}  
        elseif (-not ($Location.name -and $Location.id -and ($Location.type -eq 'folder' -or $Location.type -eq 'Album'  ) ))  {Write-Warning "Not a valid Location"}
        elseif ($PSCmdlet.ShouldProcess(($Location.type + ": " + $Location.name),"Add OneDrive folder")) { 
                $myBody    = @{name=$name} | ConvertTo-Json
                $NewFolder = Invoke-RestMethod -Method Post -Uri "$wlApiUri/$($Location.id)" -Headers @{"Authorization" = "Bearer " + $wlAccess} -ContentType "application/json" -Body $myBody 
                $NewFolder.pstypenames.Add("OneDriveItem")
                Add-member -InputObject $NewFolder -name "GetItems" -membertype ScriptMethod -Value {Get-OneDrive $this} -PassThru  
                Add-member -InputObject $Location -name ($name -replace "\W","_") -membertype Noteproperty -Value $newfolder -Force 
                if ($Location.children) {$Location.children = $Location.children +  $NewFolder     }
        }
  }
}

#endregion


#region OneNOTE
Function Out-OneNoteLive {
<#
.Synopsis
   Output to a new one note live page
.DESCRIPTION
   Long description
.INPUTS
    You can pipe any .NET object to Out-OneNoteLive
 .OUTPUTS 
    Returns a string containing the URL to open the new page in a browser      
.EXAMPLE
   Get-Process | Out-OneNoteLive -Title "Processes @ $(get-date)" -property Name,Handles,NPM,PM,VM,WS 
   Generates a page
.EXAMPLE
   start ( Get-Process | Out-OneNoteLive -Title "Processes @ $(get-date)" -property Name,Handles,NPM,PM,VM,WS )
   Generates a page and opens it
#>
 Param   ( #Specifies the objects to be represented in HTML. 
            [parameter(ValueFromPipeline=$true)]
            [psobject]$InputObject,
            #Includes the specified properties of the objects in the 
            [Parameter(Position=0)]
            [System.Object[]]
            $Property,
            [Parameter(ParameterSetName='Page', Position=3)]
            #Specifies the text to add after the opening <BODY> tag. By default, there is no text in that position.
            [string[]]$Body,
            #Specifies the content of the <HEAD> tag. The default is "<title>HTML TABLE</title>".  If you use the Head parameter, the Title parameter is ignored.
            [Parameter(ParameterSetName='Page', Position=1)]
            [string[]]
            $Head,
            #Specifies a title for the Page.
            [Parameter(ParameterSetName='Page', Position=2)]
            [ValidateNotNullOrEmpty()][string]$Title,
            #Determines whether the object is formatted as a table or a list. Valid values are TABLE and LIST. The default value is TABLE.
            [ValidateSet('Table','List')][string]$As = 'Table',
            #Generates only an HTML table. The HTML, HEAD, TITLE, and BODY tags are omitted.
            [Parameter(ParameterSetName='Fragment')]
            [ValidateNotNullOrEmpty()][switch]$Fragment,
            # Specifies text to add before the opening <TABLE> tag. By default, there is no text in that position.
            [ValidateNotNullOrEmpty()][string[]]$PreContent,
            #Specifies text to add after the closing </TABLE> tag. By default, there is no text in that position.
            [ValidateNotNullOrEmpty()][string[]]$PostContent           
         )
 Begin   { $stuff = @() } 
 Process { $Stuff = $Stuff + $InputObject} 
 End     { if (Use-WindowsLive -Scope "wl.basic", "Office.onenote_create") {
                if (-not $Title)    {$PSBoundParameters.Add("Title", ( $MyInvocation.Line + "  -  " +  (Get-Date))) }
                [void]$PSBoundParameters.Remove("InputObject")
                $myhtml = $Stuff | ConvertTo-Html  @PSBoundParameters
                $result =  Invoke-RestMethod -Method Post -Uri $wlOneNoteURI -Headers @{"Authorization" = "Bearer " + $wlAccess} -ContentType "text/html" -Body $myhtml 
                $result.links.onenoteWebUrl.href
         }}
 }

function Copy-ToOneNoteLive {
<#
  .Synopsis
    Copies the currently selected text in the current file to one note live 
  .Description
    Copies the currently selected text in the current file as colorized HTML
    Needs Write-ColorizedHTML from the ISE pack
  .Example
    Copy-ToOneNoteLive
#>
   Param ( #Specifies a title for the Page. File name will be used otherwise 
           $Title)
   if (-not $psise.CurrentFile) {
        Write-Error 'You must have an open script file'
        return
   }
   elseif (Use-WindowsLive -Scope "wl.basic", "Office.onenote_create") {
        if (-not $Title)    {$Title = $psise.CurrentFile.DisplayName}
        $selectedEditor=$psise.CurrentFile.Editor
        if ( $selectedEditor.SelectedText) {$colorizedText = Write-ColorizedHTML $selectedEditor.SelectedText}
        else                               {$colorizedText = Write-ColorizedHTML $selectedEditor.Text}
        $colorizedText = "<html><head><title>$Title</title></head><body>$colorizedText</body></html>"
        $result =  Invoke-RestMethod -Method Post -Uri $wlOneNoteURI -Headers @{"Authorization" = "Bearer " + $wlAccess} `
                                     -ContentType "text/html" -Body $colorizedText 
        $result.links.onenoteWebUrl.href
   }   
}
#endregion

if (-not ($psise.CurrentPowerShellTab.AddOnsMenu.Submenus | where displayname -eq "Copy to OneNote Online")) { 
  [void]$psise.CurrentPowerShellTab.AddOnsMenu.Submenus.Add("Copy to OneNote Online",{Copy-ToOneNoteLive},"CTRL + L")}

<#
(Invoke-RestMethod -Uri ("$wlApiUri/" + $calendars[0].id + "/events?access_token=$wlAccess`?start_time=2011-08-01T00:00:00Z&end_time=2014-08-03T00:00:00Z") ).data

$contacts         = (Invoke-RestMethod -Uri "$wlApiUri/me/contacts?access_token=$wlAccess").data 
$calendars        = (Invoke-RestMethod -Uri "$wlApiUri/me/calendars?access_token=$wlAccess").data 
$events           = (Invoke-RestMethod -Uri "$wlApiUri/me/events?access_token=$wlAccess").data

Invoke-RestMethod -Uri "$wlApiUri/$fileid/content?access_token=$wlAccess" -OutFile c:\temp\test2.zip

wl.contacts_create 
$contact = @{  first_name="Jack"; last_name="Smith"; emails=@{preferred="jsmith@contoso.com";business="Jack.Smith@contoso.com"} } | ConvertTo-Json
Invoke-RestMethod -Uri "$wlApiUri/me/contacts?access_token=$wlAccess" -Method Post -ContentType "application/json" -Body $contact

POST https://apis.live.net/v5.0/me/contacts
Authorization: Bearer ACCESS_TOKEN
Content-Type: application/json
{
    "first_name": "Roberto",
    "last_name": "Tamburello"
}

POST https://apis.live.net/v5.0/me/events 
Authorization: Bearer ACCESS_TOKEN
Content-Type: application/json
{
    "name: "Family Dinner",
    "description": "Dinner with Cynthia's family",
    "start_time": "2011-03-22T01:30:00-08:00",
    "end_time": "2011-03-22T03:00:00-08:00",
    "location": "Coho Vineyard and Winery, 123 Main St., Redmond WA 19532",
    "is_all_day_event": false,
    "availability": "busy",
    "visibility": "public"
}
PUT https://apis.live.net/v5.0/event.c76d2a8c4e674ff9bc96f17dee3c34c9.b987b00b77194723b8c16bbe57a03037
Authorization: Bearer ACCESS_TOKEN
Content-Type: application/json
{
    "name": "My example event has changed"
}
DELETE https://apis.live.net/v5.0/event.c76d2a8c4e674ff9bc96f17dee3c34c9.b987b00b77194723b8c16bbe57a03037?access_token=ACCESS_TOKEN
#>

if (Use-WindowsLive) {
    $folderCount = (Get-OneDrive -init -filter "albums","folders").count
    write-host ("{0} has {1} folders in root of OneDrive, and {2:F1}GB free from a quota of {3:F1}GB"  -f $onedrive.UserName,$folderCount,($OneDrive.available/1gb), ($OneDrive.quota/1GB))
}